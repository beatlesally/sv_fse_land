package at.itkollegimst.studentenverwaltung.exceptions;

public class StudentNichtGefunden extends Exception {

    public StudentNichtGefunden(String message) {
        super(message);
    }
}
