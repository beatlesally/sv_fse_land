package at.itkollegimst.studentenverwaltung;

import org.junit.jupiter.api.Test;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentenverwaltungApplicationTests  {

	@Test
	void contextLoads() {
	}

}
