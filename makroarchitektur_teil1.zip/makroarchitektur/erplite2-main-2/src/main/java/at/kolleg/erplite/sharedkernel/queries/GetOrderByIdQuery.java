package at.kolleg.erplite.sharedkernel.queries;

public record GetOrderByIdQuery(String orderId) {
}
