package at.itkolleg.delivery.sharedkernel;

public record OrderInDeliveryEvent(String orderID) {
}
