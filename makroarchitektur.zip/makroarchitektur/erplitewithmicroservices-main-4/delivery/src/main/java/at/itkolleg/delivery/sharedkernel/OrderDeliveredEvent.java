package at.itkolleg.delivery.sharedkernel;

public record OrderDeliveredEvent(String orderID) {
}
