package com.example.erpliteapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayTests {

    @Test
    void contextLoads() {
    }

}
