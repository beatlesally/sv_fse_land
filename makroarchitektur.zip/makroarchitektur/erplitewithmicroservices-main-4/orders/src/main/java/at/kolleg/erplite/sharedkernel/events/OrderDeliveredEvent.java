package at.kolleg.erplite.sharedkernel.events;

public record OrderDeliveredEvent(String orderID) {
}
