package at.kolleg.erplite.sharedkernel.events;

public record OrderStateChangedEvent() {
}
