package at.itkolleg.erpliteservicedisc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDiscoveryTests {

    @Test
    void contextLoads() {
    }

}
