package at.kolleg.erplite.customermanagement.usecases.commands;

public record CustomerCreationCommand() {
}
