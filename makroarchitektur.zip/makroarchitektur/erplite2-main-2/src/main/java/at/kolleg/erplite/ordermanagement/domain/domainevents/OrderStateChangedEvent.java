package at.kolleg.erplite.ordermanagement.domain.domainevents;

public record OrderStateChangedEvent() {
}
