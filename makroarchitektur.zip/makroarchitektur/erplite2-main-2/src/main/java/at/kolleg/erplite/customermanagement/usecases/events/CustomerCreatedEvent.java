package at.kolleg.erplite.customermanagement.usecases.events;

public record CustomerCreatedEvent() {
}
